import * as universal from "../../../src/routes/signUp/+page.ts";
export { universal };
export { default as component } from "../../../src/routes/signUp/+page.svelte";