import * as universal from "../../../src/routes/search/+page.ts";
export { universal };
export { default as component } from "../../../src/routes/search/+page.svelte";