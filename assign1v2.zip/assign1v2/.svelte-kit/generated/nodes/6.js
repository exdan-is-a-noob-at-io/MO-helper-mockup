import * as universal from "../../../src/routes/question/[question_id]/+page.ts";
export { universal };
export { default as component } from "../../../src/routes/question/[question_id]/+page.svelte";