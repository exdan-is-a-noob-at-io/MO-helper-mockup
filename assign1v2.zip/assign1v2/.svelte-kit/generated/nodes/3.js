import * as universal from "../../../src/routes/contact/+page.ts";
export { universal };
export { default as component } from "../../../src/routes/contact/+page.svelte";