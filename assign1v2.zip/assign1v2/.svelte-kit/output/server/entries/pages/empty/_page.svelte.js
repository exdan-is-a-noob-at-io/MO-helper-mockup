import { c as create_ssr_component } from "../../../chunks/index.js";
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  console.log("hi");
  return ``;
});
export {
  Page as default
};
