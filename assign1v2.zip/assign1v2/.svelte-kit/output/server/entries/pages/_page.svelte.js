import { c as create_ssr_component, v as validate_component } from "../../chunks/index.js";
import { S as SearchComponent } from "../../chunks/SearchComponent.js";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: 'header.svelte-uwgzrm.svelte-uwgzrm{display:flex;flex-direction:column;align-items:center;text-align:center;background:linear-gradient(#020007, #0B0621);position:relative}header.svelte-uwgzrm.svelte-uwgzrm::before{content:"";position:absolute;width:100%;height:100%;background-color:rgba(255, 255, 255, 0.05);background-repeat:repeat;mask-size:5.76rem;-webkit-mask-size:5.76rem;mask-image:url("$lib/images/bamboo.svg");-webkit-mask-image:url("$lib/images/bamboo.svg")}header.svelte-uwgzrm>h1.svelte-uwgzrm{z-index:1}h1.svelte-uwgzrm.svelte-uwgzrm{font-size:3.84rem;margin-top:20rem;margin-bottom:11rem;font-size:64px;line-height:124.5%;letter-spacing:0.05em;background:linear-gradient(#fff , #5D35FF);color:transparent;text-shadow:0px 4px 32px #5D35FF;background-clip:text;-webkit-background-clip:text}',
  map: null
};
const pageMax = 10;
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  var displayedPageNo = [];
  var currPage = 0;
  const updatePageSelector = (currPage_) => {
    currPage = currPage_;
    var displayedPagesInt = [];
    displayedPagesInt.push(1);
    const nPlus2 = Math.min(currPage_ + 1, pageMax - 2);
    if (currPage_ - 3 < 2) {
      for (var i = 1; i <= nPlus2; ++i) {
        displayedPagesInt.push(i + 1);
      }
    } else {
      displayedPagesInt.push(null);
      for (var i = currPage_ - 3; i <= nPlus2; ++i) {
        displayedPagesInt.push(i + 1);
      }
    }
    if (nPlus2 + 2 >= pageMax) {
      displayedPagesInt.push(pageMax);
    } else {
      displayedPagesInt.push(null);
      displayedPagesInt.push(pageMax);
    }
    displayedPageNo = [{ value: "<", enabled: currPage != 1 }];
    for (var i = 0; i < displayedPagesInt.length; ++i) {
      var toAppend = displayedPagesInt[i];
      displayedPageNo.push({
        value: toAppend == null ? "..." : toAppend.toString(),
        enabled: toAppend != null
      });
    }
    displayedPageNo.push({ value: ">", enabled: currPage != pageMax });
  };
  updatePageSelector(1);
  $$result.css.add(css);
  return `<header class="${"svelte-uwgzrm"}"><h1 class="${"svelte-uwgzrm"}">Track Olympiad problems <br>
        with ease.
    </h1></header>

${validate_component(SearchComponent, "SearchComponent").$$render($$result, { query: "", pageMax: 20, currPage: 1 }, {}, {})}`;
});
export {
  Page as default
};
