const load = async ({ url }) => {
  return { url };
};
export {
  load
};
