import { c as create_ssr_component, v as validate_component } from "../../../chunks/index.js";
import { S as SearchComponent } from "../../../chunks/SearchComponent.js";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "div.svelte-2eiu9g{padding-top:15rem}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { data } = $$props;
  let query = data.url.searchParams.get("q");
  let pageMax = data.url.searchParams.get("pageMax");
  let currPage = data.url.searchParams.get("currPage");
  let querySanitised = query == null ? "" : query;
  let pageMaxSanitised = pageMax == null ? 1 : parseInt(pageMax);
  let currPageSanitised = currPage == null ? 1 : parseInt(currPage);
  if (currPageSanitised < pageMaxSanitised)
    currPageSanitised = 1;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  $$result.css.add(css);
  return `<div class="${"svelte-2eiu9g"}">${validate_component(SearchComponent, "SearchComponent").$$render(
    $$result,
    {
      query: querySanitised,
      pageMax: pageMaxSanitised,
      currPage: currPageSanitised
    },
    {},
    {}
  )}
</div>`;
});
export {
  Page as default
};
