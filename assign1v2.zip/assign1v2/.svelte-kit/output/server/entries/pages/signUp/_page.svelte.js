import { c as create_ssr_component, b as add_attribute } from "../../../chunks/index.js";
import { e as eyeClosedIcon } from "../../../chunks/eyeClosed.js";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "main.svelte-15xa85x.svelte-15xa85x{min-height:calc(100vh - 10.5rem);padding-top:10.5rem;display:grid;place-items:center}h1.svelte-15xa85x.svelte-15xa85x{font-size:2rem;margin-bottom:4.32rem}form.svelte-15xa85x.svelte-15xa85x{background:var(--primary-background-100);padding:3.24rem 3.72rem;border:2px solid var(--primary-color-700);border-radius:12px;box-shadow:6px -6px 12px 0px rgba(102, 51, 255, 0.25),\r\n         0px 0px 64px 0px rgba(64, 0, 255, 0.25)}form.svelte-15xa85x>div.svelte-15xa85x{display:flex;flex-direction:column;margin-top:3.3rem;position:relative}form.svelte-15xa85x>div.svelte-15xa85x:first-of-type{margin-top:0}label.svelte-15xa85x.svelte-15xa85x{position:absolute;top:-1.8rem;color:var(--primary-color-800)}input.svelte-15xa85x.svelte-15xa85x:not([type=submit]){background:var(--primary-background-400);border:none;outline:none;width:min(430px, 80vw);height:2.64rem;border-radius:8px;box-sizing:border-box;padding:0 1rem;position:relative}input[type=submit].svelte-15xa85x.svelte-15xa85x{background:var(--primary-accent);border:none;outline:none;text-transform:uppercase;letter-spacing:0.1rem;font-weight:bold;height:2.64rem;border-radius:8px;box-sizing:border-box;padding:0 1rem;box-shadow:0px 4px 0px 0px rgba(80, 32, 223, 1);transition:all 0.1s ease-in-out;cursor:pointer}input[type=submit].svelte-15xa85x.svelte-15xa85x:hover{box-shadow:0px 2px 0px 0px rgba(80, 32, 223, 1);transform:translateY(2px)}input[type=submit].svelte-15xa85x.svelte-15xa85x:active{box-shadow:0px 0px 0px 0px rgba(80, 32, 223, 1);transform:translateY(4px);filter:brightness(80%) hue-rotate(-5deg)}input.svelte-15xa85x:not([type=submit])+button.svelte-15xa85x{position:absolute;background:transparent;border:none;outline:none;right:0;margin-right:1rem;height:100%;cursor:pointer}img.svelte-15xa85x.svelte-15xa85x{display:block}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let type;
  let eyeState;
  $$result.css.add(css);
  type = "password";
  eyeState = eyeClosedIcon;
  return `<main class="${"svelte-15xa85x"}"><form class="${"svelte-15xa85x"}"><h1 class="${"svelte-15xa85x"}">Make Account ✨</h1>
        <div class="${"svelte-15xa85x"}"><label for="${"username"}" class="${"textboxHeader svelte-15xa85x"}">Username</label>
            <input type="${"text"}" name="${"username"}" class="${"svelte-15xa85x"}"></div>
        <div class="${"svelte-15xa85x"}"><label for="${"email"}" class="${"textboxHeader svelte-15xa85x"}">Email</label>
            <input type="${"email"}" name="${"email"}" class="${"svelte-15xa85x"}"></div>
        <div class="${"svelte-15xa85x"}"><label for="${"password"}" class="${"textboxHeader svelte-15xa85x"}">Password</label>
            <input${add_attribute("type", type, 0)} name="${"password"}" class="${"svelte-15xa85x"}">
            <button class="${"svelte-15xa85x"}"><img${add_attribute("src", eyeState, 0)} alt="${"Uncover password"}" class="${"svelte-15xa85x"}"></button></div>
        <div class="${"svelte-15xa85x"}"><input type="${"submit"}" value="${"Register"}" class="${"svelte-15xa85x"}"></div>
        <div class="${"svelte-15xa85x"}"><span>Have an account?
                <a href="${"/login"}">Log In!</a></span></div></form>
</main>`;
});
export {
  Page as default
};
