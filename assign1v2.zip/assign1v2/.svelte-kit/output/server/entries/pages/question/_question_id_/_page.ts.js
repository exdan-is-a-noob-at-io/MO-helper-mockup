const load = ({ params }) => {
  return {
    questionId: params.question_id
  };
};
export {
  load
};
