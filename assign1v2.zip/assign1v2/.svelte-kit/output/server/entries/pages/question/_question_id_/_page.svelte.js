import { c as create_ssr_component, e as escape } from "../../../../chunks/index.js";
import { marked } from "marked";
import katex from "katex";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "h1.svelte-1eqd2kg{margin-top:200px;font-size:2rem}main.svelte-1eqd2kg{width:100%;display:flex;flex-direction:column;align-items:center}article.svelte-1eqd2kg{max-width:28.8rem}code{margin:0}code > *{display:inline;background:var(--primary-background-400);border:1px solid var(--primary-color-600);padding:1rem;margin:0;border-radius:8px}.katex-display{margin:0}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  marked.setOptions({
    renderer: new marked.Renderer(),
    highlight(code, language) {
      if (language !== "katex") {
        return code;
      }
      const mathcode = katex.renderToString(code, {
        throwOnError: false,
        displayMode: true,
        output: "html"
      });
      return mathcode;
    }
  });
  let content = "";
  let toParse = `Let  
\`\`\`katex  
a_1, a_2, \\dots, a_n  
\`\`\`  
be a sequence of real numbers, and let  
\`\`\`katex  
m  
\`\`\``;
  marked.parse(toParse, function(error, result) {
    content = result;
    console.log(content);
  });
  let { data } = $$props;
  if ($$props.data === void 0 && $$bindings.data && data !== void 0)
    $$bindings.data(data);
  $$result.css.add(css);
  return `<h1 class="${"svelte-1eqd2kg"}">Note that this page is still under construction. The rest of this page is an attempt of using Katex with sveltekit and failing. 
</h1>

<h1 class="${"svelte-1eqd2kg"}">${escape(data.questionId)}</h1>

<main class="${"svelte-1eqd2kg"}"><article class="${"svelte-1eqd2kg"}"><!-- HTML_TAG_START -->${content}<!-- HTML_TAG_END --></article></main>


`;
});
export {
  Page as default
};
