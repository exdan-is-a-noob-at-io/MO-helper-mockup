import { c as create_ssr_component, b as add_attribute } from "../../chunks/index.js";
const logo = "/_app/immutable/assets/Logo-d21dc16d.svg";
const _layout_svelte_svelte_type_style_lang = "";
const css = {
  code: 'body{background:linear-gradient(#0F0C1D, #0B0621);min-height:100vh}*{--primary-color-900:#E7E6FB;--primary-color-800:#C2B0F7;--primary-color-700:#B09AEF;--primary-color-600:#6B3DB7;--primary-color-300:#534F7F;--primary-background-400:#291C51;--primary-background-300:#0B0621;--primary-background-200:#0F0C1D;--primary-background-100:#020007;--primary-accent:#8157FF;--primary-font:"Poppins";padding:0;margin:0;color:var(--primary-color-900);font-size:1rem;text-rendering:optimizeLegibility;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased}@font-face{font-family:"Poppins";src:url("$lib/fonts/Poppins-Regular.ttf");font-weight:normal}@font-face{font-family:"Poppins";src:url("$lib/fonts/Poppins-Bold.ttf");font-weight:bold}a.svelte-1ltgd9c.svelte-1ltgd9c.svelte-1ltgd9c{font-weight:bold;line-height:24px;text-decoration:none}nav.svelte-1ltgd9c.svelte-1ltgd9c.svelte-1ltgd9c{position:absolute;display:flex;flex-direction:row;justify-content:space-between;left:7.56rem;right:7.56rem;top:5.58rem;z-index:100;font-family:var(--primary-font)}img.svelte-1ltgd9c.svelte-1ltgd9c.svelte-1ltgd9c{display:block}ul.svelte-1ltgd9c.svelte-1ltgd9c.svelte-1ltgd9c{display:flex;flex-direction:row;align-items:center;gap:1.44rem}li.svelte-1ltgd9c.svelte-1ltgd9c.svelte-1ltgd9c{list-style:none}button.svelte-1ltgd9c.svelte-1ltgd9c.svelte-1ltgd9c{border:0;background:var(--primary-accent);border-radius:8px;padding:0.75rem 2.5rem;font-weight:bold;cursor:pointer;transition:all 0.1s ease-in-out;font-family:var(--primary-font)}button.svelte-1ltgd9c.svelte-1ltgd9c.svelte-1ltgd9c:hover{background:var(--primary-background-400)}footer.svelte-1ltgd9c.svelte-1ltgd9c.svelte-1ltgd9c{margin-top:0.75rem;padding:2.7rem 17.34rem 7.27rem 17.34rem;font-family:var(--primary-font);background:var(--primary-background-100)}footer.svelte-1ltgd9c>ul.svelte-1ltgd9c.svelte-1ltgd9c{justify-content:space-between}footer.svelte-1ltgd9c>ul.svelte-1ltgd9c>li.svelte-1ltgd9c:first-of-type{display:flex;flex-direction:row;align-items:center}footer.svelte-1ltgd9c>ul.svelte-1ltgd9c>li:first-of-type .svelte-1ltgd9c{color:var(--primary-color-300)}.main.svelte-1ltgd9c.svelte-1ltgd9c.svelte-1ltgd9c{min-height:100vh;font-family:var(--primary-font)}',
  map: null
};
const Layout = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  const prerender = true;
  if ($$props.prerender === void 0 && $$bindings.prerender && prerender !== void 0)
    $$bindings.prerender(prerender);
  $$result.css.add(css);
  return `<nav class="${"svelte-1ltgd9c"}"><ul id="${"pages"}" class="${"svelte-1ltgd9c"}"><li class="${"svelte-1ltgd9c"}"><a href="${"/"}" class="${"svelte-1ltgd9c"}"><img${add_attribute("src", logo, 0)} alt="${"StackUnderflow"}" class="${"svelte-1ltgd9c"}"></a></li>
        <li class="${"svelte-1ltgd9c"}"><a href="${"/"}" class="${"svelte-1ltgd9c"}">Home</a></li>
        <li class="${"svelte-1ltgd9c"}"><a href="${"/contact"}" class="${"svelte-1ltgd9c"}">Contact Us</a></li></ul>
    <ul id="${"account"}" class="${"svelte-1ltgd9c"}"><li class="${"svelte-1ltgd9c"}"><a href="${"/login"}" class="${"svelte-1ltgd9c"}">Login</a></li>
        <li class="${"svelte-1ltgd9c"}"><button class="${"svelte-1ltgd9c"}">Sign Up
            </button></li></ul></nav>

<div class="${"main svelte-1ltgd9c"}">${slots.default ? slots.default({}) : ``}</div>

<footer class="${"svelte-1ltgd9c"}"><ul class="${"svelte-1ltgd9c"}"><li class="${"svelte-1ltgd9c"}"><a href="${"/"}" class="${"svelte-1ltgd9c"}"><img${add_attribute("src", logo, 0)} alt="${"StackUnderflow"}" class="${"svelte-1ltgd9c"}"></a>            
            <div class="${"svelte-1ltgd9c"}">by monya~
            </div></li>
        <li class="${"svelte-1ltgd9c"}"><a href="${"/contact"}" class="${"svelte-1ltgd9c"}">Contact us
            </a></li></ul>
</footer>`;
});
export {
  Layout as default
};
