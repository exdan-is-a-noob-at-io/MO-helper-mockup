import { c as create_ssr_component, b as add_attribute } from "../../../chunks/index.js";
const send = "/_app/immutable/assets/send-75faf995.svg";
const _page_svelte_svelte_type_style_lang = "";
const css = {
  code: "main.svelte-1oslh7d.svelte-1oslh7d{min-height:calc(100vh - 10.5rem);padding-top:10.5rem;display:grid;place-items:center}h1.svelte-1oslh7d.svelte-1oslh7d{font-size:2rem;font-style:bold}p.svelte-1oslh7d.svelte-1oslh7d{color:var(--primary-color-900)}form.svelte-1oslh7d>div.svelte-1oslh7d:not(:last-of-type){display:flex;flex-direction:column;margin-top:3.3rem;position:relative}form.svelte-1oslh7d>div.svelte-1oslh7d:first-of-type{margin-top:0}label.svelte-1oslh7d.svelte-1oslh7d{position:absolute;top:-1.8rem;left:0.08rem;color:var(--primary-color-800);font-size:0.84rem}input.svelte-1oslh7d.svelte-1oslh7d:not([type=submit]){background:var(--primary-background-100);width:304px;height:2.64rem;border-radius:8px;box-sizing:border-box;padding:0 1rem;color:var(--primary-background-900);border:2px solid #7671B0;box-shadow:inset 0px -4px 4px #1A132C;position:relative;word-break:break-word}textarea.svelte-1oslh7d.svelte-1oslh7d{background:var(--primary-background-100);width:551px;height:212px;box-sizing:border-box;padding:10px 1rem;resize:none;background:var(--primary-background-100);border:2px solid #7671B0;box-shadow:inset 0px -4px 4px #1A132C;border-radius:8px;position:relative}form.svelte-1oslh7d>div.svelte-1oslh7d:last-of-type{position:relative;display:block;width:fit-content;margin-top:2rem;margin-left:auto}form.svelte-1oslh7d>div:last-of-type img.svelte-1oslh7d{position:absolute;height:100%;width:16px;display:block;right:1.6rem;top:0}input[type=submit].svelte-1oslh7d.svelte-1oslh7d{background:var(--primary-accent);border:none;outline:none;width:158px;height:49px;text-transform:uppercase;letter-spacing:0.1rem;font-weight:bold;height:2.64rem;border-radius:8px;box-sizing:border-box;padding:0 1rem;box-shadow:0px 4px 0px 0px rgba(80, 32, 223, 1);transition:all 0.1s ease-in-out;cursor:pointer}form.svelte-1oslh7d>div.svelte-1oslh7d:last-of-type:hover{box-shadow:0px 2px 0px 0px rgba(80, 32, 223, 1);transform:translateY(2px)}form.svelte-1oslh7d>div.svelte-1oslh7d:last-of-type:active{box-shadow:0px 0px 0px 0px rgba(80, 32, 223, 1);transform:translateY(4px);filter:brightness(80%) hue-rotate(-5deg)}",
  map: null
};
const Page = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  $$result.css.add(css);
  return `<main class="${"svelte-1oslh7d"}"><form class="${"svelte-1oslh7d"}"><div class="${"svelte-1oslh7d"}"><h1 class="${"svelte-1oslh7d"}">Have a Suggestion?</h1>
            <p class="${"svelte-1oslh7d"}">Let us Know!</p></div>
        <div class="${"svelte-1oslh7d"}"><label for="${"name"}" class="${"textboxHeader svelte-1oslh7d"}">Name</label>
            <input type="${"text"}" name="${"name"}" class="${"svelte-1oslh7d"}"></div>
        <div class="${"svelte-1oslh7d"}"><label for="${"email"}" class="${"textboxHeader svelte-1oslh7d"}">Email</label>
            <input type="${"email"}" name="${"email"}" class="${"svelte-1oslh7d"}"></div>
        <div class="${"svelte-1oslh7d"}"><label for="${"message"}" class="${"textboxHeader svelte-1oslh7d"}">Message</label>
            <textarea name="${"message"}" class="${"svelte-1oslh7d"}"></textarea>
            </div>
        <div class="${"svelte-1oslh7d"}"><input type="${"submit"}" value="${"Send    "}" class="${"svelte-1oslh7d"}">
            <img alt="${"Send icon"}"${add_attribute("src", send, 0)} class="${"svelte-1oslh7d"}"></div></form>
</main>`;
});
export {
  Page as default
};
