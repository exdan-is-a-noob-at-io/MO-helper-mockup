import * as universal from '../entries/pages/login/_page.ts.js';

export const index = 5;
export const component = async () => (await import('../entries/pages/login/_page.svelte.js')).default;
export const file = '_app/immutable/components/pages/login/_page.svelte-7368dcd5.js';
export { universal };
export const imports = ["_app/immutable/components/pages/login/_page.svelte-7368dcd5.js","_app/immutable/chunks/index-e76d9c11.js","_app/immutable/chunks/index-bfae7857.js","_app/immutable/chunks/eyeClosed-7930cd15.js","_app/immutable/modules/pages/login/_page.ts-63d63436.js","_app/immutable/chunks/_page-e76ae232.js"];
export const stylesheets = ["_app/immutable/assets/_page-9a9f7580.css"];
export const fonts = [];
