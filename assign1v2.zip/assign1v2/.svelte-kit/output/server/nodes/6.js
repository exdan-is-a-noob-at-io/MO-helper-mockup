import * as universal from '../entries/pages/question/_question_id_/_page.ts.js';

export const index = 6;
export const component = async () => (await import('../entries/pages/question/_question_id_/_page.svelte.js')).default;
export const file = '_app/immutable/components/pages/question/_question_id_/_page.svelte-9ae4c06b.js';
export { universal };
export const imports = ["_app/immutable/components/pages/question/_question_id_/_page.svelte-9ae4c06b.js","_app/immutable/chunks/index-e76d9c11.js","_app/immutable/modules/pages/question/_question_id_/_page.ts-d9920873.js","_app/immutable/chunks/_page-e58add58.js"];
export const stylesheets = ["_app/immutable/assets/_page-92a4535a.css"];
export const fonts = [];
