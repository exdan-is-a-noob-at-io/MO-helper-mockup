import * as universal from '../entries/pages/contact/_page.ts.js';

export const index = 3;
export const component = async () => (await import('../entries/pages/contact/_page.svelte.js')).default;
export const file = '_app/immutable/components/pages/contact/_page.svelte-6325eaac.js';
export { universal };
export const imports = ["_app/immutable/components/pages/contact/_page.svelte-6325eaac.js","_app/immutable/chunks/index-e76d9c11.js","_app/immutable/chunks/index-bfae7857.js","_app/immutable/modules/pages/contact/_page.ts-63d63436.js","_app/immutable/chunks/_page-df57698a.js"];
export const stylesheets = ["_app/immutable/assets/_page-b7bb7756.css"];
export const fonts = [];
