

export const index = 0;
export const component = async () => (await import('../entries/pages/_layout.svelte.js')).default;
export const file = '_app/immutable/components/pages/_layout.svelte-8b082790.js';
export const imports = ["_app/immutable/components/pages/_layout.svelte-8b082790.js","_app/immutable/chunks/index-e76d9c11.js","_app/immutable/chunks/navigation-ce665813.js","_app/immutable/chunks/singletons-bef291f5.js"];
export const stylesheets = ["_app/immutable/assets/_layout-4f667781.css"];
export const fonts = ["_app/immutable/assets/Poppins-Regular-707fdc5c.ttf","_app/immutable/assets/Poppins-Bold-7219547e.ttf"];
