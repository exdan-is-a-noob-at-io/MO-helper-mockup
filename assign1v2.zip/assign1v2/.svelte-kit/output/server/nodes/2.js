

export const index = 2;
export const component = async () => (await import('../entries/pages/_page.svelte.js')).default;
export const file = '_app/immutable/components/pages/_page.svelte-d8237e60.js';
export const imports = ["_app/immutable/components/pages/_page.svelte-d8237e60.js","_app/immutable/chunks/index-e76d9c11.js","_app/immutable/chunks/SearchComponent-2622212e.js","_app/immutable/chunks/index-bfae7857.js","_app/immutable/chunks/navigation-ce665813.js","_app/immutable/chunks/singletons-bef291f5.js"];
export const stylesheets = ["_app/immutable/assets/_page-1bae7735.css","_app/immutable/assets/SearchComponent-b39870ba.css"];
export const fonts = [];
