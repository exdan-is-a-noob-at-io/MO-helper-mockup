import * as universal from '../entries/pages/empty/_page.ts.js';

export const index = 4;
export const component = async () => (await import('../entries/pages/empty/_page.svelte.js')).default;
export const file = '_app/immutable/components/pages/empty/_page.svelte-6b628d40.js';
export { universal };
export const imports = ["_app/immutable/components/pages/empty/_page.svelte-6b628d40.js","_app/immutable/chunks/index-e76d9c11.js","_app/immutable/modules/pages/empty/_page.ts-63d63436.js","_app/immutable/chunks/_page-816eaffb.js"];
export const stylesheets = [];
export const fonts = [];
