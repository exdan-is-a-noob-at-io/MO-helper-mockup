import * as universal from '../entries/pages/search/_page.ts.js';

export const index = 7;
export const component = async () => (await import('../entries/pages/search/_page.svelte.js')).default;
export const file = '_app/immutable/components/pages/search/_page.svelte-05087573.js';
export { universal };
export const imports = ["_app/immutable/components/pages/search/_page.svelte-05087573.js","_app/immutable/chunks/index-e76d9c11.js","_app/immutable/chunks/SearchComponent-2622212e.js","_app/immutable/chunks/index-bfae7857.js","_app/immutable/chunks/navigation-ce665813.js","_app/immutable/chunks/singletons-bef291f5.js","_app/immutable/modules/pages/search/_page.ts-ec09addf.js","_app/immutable/chunks/_page-816df066.js"];
export const stylesheets = ["_app/immutable/assets/_page-663dbdda.css","_app/immutable/assets/SearchComponent-b39870ba.css"];
export const fonts = [];
