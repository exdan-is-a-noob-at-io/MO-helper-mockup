

export const index = 1;
export const component = async () => (await import('../entries/fallbacks/error.svelte.js')).default;
export const file = '_app/immutable/components/error.svelte-ef8ac4ec.js';
export const imports = ["_app/immutable/components/error.svelte-ef8ac4ec.js","_app/immutable/chunks/index-e76d9c11.js","_app/immutable/chunks/singletons-bef291f5.js"];
export const stylesheets = [];
export const fonts = [];
