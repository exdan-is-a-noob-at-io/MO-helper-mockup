import { c as create_ssr_component, f as createEventDispatcher, b as add_attribute, e as escape, h as add_styles, v as validate_component, i as each } from "./index.js";
const searchIcon = "/_app/immutable/assets/search-9d047b55.svg";
const SearchInput_svelte_svelte_type_style_lang = "";
const css$2 = {
  code: '.search.svelte-xj6fc3.svelte-xj6fc3{position:relative;top:-2.04rem;display:block}input[type="search"].svelte-xj6fc3.svelte-xj6fc3{background:var(--primary-background-200);padding:1rem 3.5rem 1rem 1.5rem;width:48ch;font-size:1.25em;border:2px solid var(--primary-color-700);border-radius:8px;box-shadow:0px 22px 64px #291C51, \r\n        0px 1px 12px #8157FF}.search.svelte-xj6fc3>button.svelte-xj6fc3{box-sizing:border-box;background:transparent;border:none;position:absolute;cursor:pointer;right:1.2rem;padding-top:0.2rem;height:100%}',
  map: null
};
const SearchInput = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { queryInit } = $$props;
  let query = queryInit;
  createEventDispatcher();
  if ($$props.queryInit === void 0 && $$bindings.queryInit && queryInit !== void 0)
    $$bindings.queryInit(queryInit);
  $$result.css.add(css$2);
  return `<div class="${"search svelte-xj6fc3"}"><input type="${"search"}" class="${"svelte-xj6fc3"}"${add_attribute("value", query, 0)}>
        <button class="${"svelte-xj6fc3"}"><img${add_attribute("src", searchIcon, 0)} alt="${"Search"}"></button>
        ${slots.default ? slots.default({}) : ``}
    </div>`;
});
const QuestionCard_svelte_svelte_type_style_lang = "";
const css$1 = {
  code: 'main.svelte-10v4z1m.svelte-10v4z1m{display:flex;flex-direction:column;align-items:left;margin:1rem;box-sizing:border-box;max-width:28.5rem;background:var(--primary-background-300);border:1px solid var(--primary-background-400);border-radius:12px}.information.svelte-10v4z1m.svelte-10v4z1m{margin-right:-1px;padding:1.92rem 2.34rem;background:var(--primary-background-400);border-radius:10px}.identifier.svelte-10v4z1m.svelte-10v4z1m{font-size:1.2rem;font-weight:bold;color:var(--primary-color-300)}.extra.svelte-10v4z1m.svelte-10v4z1m{padding:0.96rem 2rem;display:grid;place-items:center;grid-template-columns:1fr 2fr}.extra.svelte-10v4z1m>.svelte-10v4z1m{color:var(--primary-color-700);font-size:12px;font-weight:bold;height:24px;display:flex;flex-direction:row;align-items:center}.country.svelte-10v4z1m.svelte-10v4z1m::before{content:url("$lib/images/globe.svg");transform:translateY(0.15rem);padding-right:0.5rem}.tags.svelte-10v4z1m.svelte-10v4z1m{display:inline-block;align-items:center;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;width:250px}.tags.svelte-10v4z1m.svelte-10v4z1m::before{display:inline-block;content:url("$lib/images/Sigma.svg");transform:translateY(0.15rem);padding-right:0.5rem}',
  map: null
};
const QuestionCard = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { question } = $$props;
  const questionFiltered = question;
  if ($$props.question === void 0 && $$bindings.question && question !== void 0)
    $$bindings.question(question);
  $$result.css.add(css$1);
  return `<main class="${"svelte-10v4z1m"}"><a style="${"text-decoration: none;"}"${add_attribute("href", "/question/" + questionFiltered.id, 0)}><div class="${"information svelte-10v4z1m"}"><div class="${"identifier svelte-10v4z1m"}">${escape(questionFiltered.id)}</div>
        <div${add_styles({
    "color": `var(--primary-color-900)`,
    "font-size": `32px`,
    "font-weight": `bold`
  })}>${escape(questionFiltered.source)}</div>
        <div${add_styles({
    "color": `var(--primary-color-900)`,
    "font-size": `16px`,
    "font-weight": `bold`,
    "font-family": `Times New Roman`
  })}>${escape(questionFiltered.statement)}</div></div>

        <div class="${"extra svelte-10v4z1m"}"><div class="${"country svelte-10v4z1m"}">${escape(questionFiltered.country)}</div>
            <div class="${"tags svelte-10v4z1m"}">${escape(questionFiltered.tags.join(", "))}</div></div></a>
    
</main>`;
});
const SearchComponent_svelte_svelte_type_style_lang = "";
const css = {
  code: 'section.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp{display:flex;flex-direction:column;align-items:center;width:100%;position:relative;background:var(--primary-background-200)\r\n    }.search.svelte-7cj1hp:is(:hover, :focus-within) .menu.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp{visibility:visible;margin-top:0.96rem;opacity:1}.search.svelte-7cj1hp .menu.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp{opacity:0;visibility:collapse;position:absolute;width:100%;line-height:1.3125rem;box-sizing:border-box;margin-top:0rem;padding:1.44rem 2.28rem;border-radius:8px;background-color:var(--primary-background-300);border:0.1rem solid #8157FF;box-shadow:0px 1px 2px rgba(0, 0, 0, 0.8),\r\n         0px 4px 16px rgba(0, 0, 0, 0.35);transition:all 0.2s ease-in-out}.search.svelte-7cj1hp .menu.svelte-7cj1hp>ul.svelte-7cj1hp.svelte-7cj1hp{display:grid;grid-template-columns:repeat(2, 1fr);gap:0.3125rem;width:100%}.search.svelte-7cj1hp .menu.svelte-7cj1hp>ul.svelte-7cj1hp>li.svelte-7cj1hp{list-style:none}#results.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp{display:flex;flex-direction:row;justify-content:center;flex-wrap:wrap;max-width:61rem}.menu.svelte-7cj1hp>ul.svelte-7cj1hp>li.svelte-7cj1hp>span.svelte-7cj1hp{font-size:0.72rem}.menu.svelte-7cj1hp>ul.svelte-7cj1hp>li.svelte-7cj1hp>span.svelte-7cj1hp:first-of-type{font-weight:bold}.menu.svelte-7cj1hp>ul.svelte-7cj1hp>li.svelte-7cj1hp>span.svelte-7cj1hp:nth-of-type(n + 2){color:var(--primary-color-700)\r\n    }.menu.svelte-7cj1hp>ul.svelte-7cj1hp>li.svelte-7cj1hp>span.svelte-7cj1hp:nth-of-type(n + 2)::before{content:"・"}#pageSelector.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp{display:flex;flex-direction:row;align-items:center;margin:3rem 0 2rem 0;gap:2rem}#pageSelector.svelte-7cj1hp>button.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp{display:grid;place-items:center;height:3rem;width:3rem;font-size:1.5rem;background:none;border-color:transparent;border-radius:100vmax;color:var(--primary-color-300);margin:0rem, 1rem;transition:all 0.1s ease-in-out;font-family:var(--primary-font)}#pageSelector.svelte-7cj1hp>button.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp:not(.disabled):hover{font-size:1.3rem;background:var(--primary-background-400);cursor:pointer}#pageSelector.svelte-7cj1hp>button.current.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp{font-weight:bold;background:var(--primary-background-400);color:var(--primary-color-900)\r\n    }#pageSelector.svelte-7cj1hp>button.side.svelte-7cj1hp.svelte-7cj1hp.svelte-7cj1hp{font-weight:bold;color:var(--primary-color-900)\r\n    }',
  map: null
};
const SearchComponent = create_ssr_component(($$result, $$props, $$bindings, slots) => {
  let { query } = $$props;
  let { pageMax } = $$props;
  let { currPage } = $$props;
  const queryRecommendations = [
    {
      "label": "topic=ACG",
      "description": "Search by year"
    },
    {
      "label": "id=2016-isl-a1",
      "description": "Search by id"
    },
    {
      "label": "year=2023",
      "description": "Search by year"
    },
    {
      "label": '"Alice and Bob"',
      "description": "exact phrase"
    },
    {
      "label": "cou=SIN",
      "description": "search within a country"
    },
    {
      "label": "tags=ISL",
      "description": "filter by tags"
    }
  ];
  const questionTemp = {
    id: "tstst-2015-1",
    source: "USA TSTST 2015 P1",
    statement: "Lorem ipsum dolor sit amet consectetur. Ultrices amet euismod lectus fames ac donec sit vulputate auctor.",
    country: "USA",
    tags: ["algebra", "geometry", "deez-nuts", "algebra", "geometry", "deez-nuts"]
  };
  var displayedPageNo = [];
  const updatePageSelector = (currPage_) => {
    currPage = currPage_;
    var displayedPagesInt = [];
    displayedPagesInt.push(1);
    const nPlus2 = Math.min(currPage_ + 1, pageMax - 2);
    if (currPage_ - 3 < 2) {
      for (var i = 1; i <= nPlus2; ++i) {
        displayedPagesInt.push(i + 1);
      }
    } else {
      displayedPagesInt.push(null);
      for (var i = currPage_ - 3; i <= nPlus2; ++i) {
        displayedPagesInt.push(i + 1);
      }
    }
    if (nPlus2 + 2 >= pageMax) {
      displayedPagesInt.push(pageMax);
    } else {
      displayedPagesInt.push(null);
      displayedPagesInt.push(pageMax);
    }
    displayedPageNo = [{ value: "<", enabled: currPage != 1 }];
    for (var i = 0; i < displayedPagesInt.length; ++i) {
      var toAppend = displayedPagesInt[i];
      displayedPageNo.push({
        value: toAppend == null ? "..." : toAppend.toString(),
        enabled: toAppend != null
      });
    }
    displayedPageNo.push({ value: ">", enabled: currPage != pageMax });
  };
  updatePageSelector(currPage);
  if ($$props.query === void 0 && $$bindings.query && query !== void 0)
    $$bindings.query(query);
  if ($$props.pageMax === void 0 && $$bindings.pageMax && pageMax !== void 0)
    $$bindings.pageMax(pageMax);
  if ($$props.currPage === void 0 && $$bindings.currPage && currPage !== void 0)
    $$bindings.currPage(currPage);
  $$result.css.add(css);
  return `<section class="${"svelte-7cj1hp"}"><div class="${"search svelte-7cj1hp"}">${validate_component(SearchInput, "SearchInput").$$render($$result, { queryInit: query }, {}, {
    default: () => {
      return `<div class="${"menu svelte-7cj1hp"}"><ul class="${"svelte-7cj1hp"}">${each(queryRecommendations, (rule) => {
        return `<li class="${"svelte-7cj1hp"}"><span class="${"svelte-7cj1hp"}">${escape(rule.label)}</span>
                            <span class="${"svelte-7cj1hp"}">${escape(rule.description)}</span>
                        </li>`;
      })}</ul></div>`;
    }
  })}</div>

    <div id="${"results"}" class="${"svelte-7cj1hp"}">${each(Array(10), (_) => {
    return `${validate_component(QuestionCard, "QuestionCard").$$render($$result, { question: questionTemp }, {}, {})}`;
  })}</div>

    <div id="${"pageSelector"}" class="${"svelte-7cj1hp"}">${each(displayedPageNo, (pageString) => {
    return `<button ${!pageString.enabled ? "disabled" : ""} class="${[
      "svelte-7cj1hp",
      (!pageString.enabled ? "disabled" : "") + " " + (pageString.value == currPage.toString() ? "current" : "") + " " + (pageString.value == "<" || pageString.value == ">" ? "side" : "")
    ].join(" ").trim()}">${escape(pageString.value)}
            </button>`;
  })}</div>
    
</section>`;
});
export {
  SearchComponent as S
};
