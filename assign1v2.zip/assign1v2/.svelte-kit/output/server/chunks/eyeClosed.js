const eyeClosedIcon = "/_app/immutable/assets/eyeClosed-fab6e59f.svg";
export {
  eyeClosedIcon as e
};
