import{S as t,i as n,s as o}from"../../../chunks/index-e76d9c11.js";function a(e){return console.log("hi"),[]}class i extends t{constructor(s){super(),n(this,s,a,null,o,{})}}export{i as default};
