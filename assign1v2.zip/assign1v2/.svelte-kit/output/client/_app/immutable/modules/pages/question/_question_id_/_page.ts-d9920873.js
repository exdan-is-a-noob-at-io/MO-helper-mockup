import{l}from"../../../../chunks/_page-e58add58.js";export{l as load};
