import{l}from"../../../chunks/_page-816df066.js";export{l as load};
