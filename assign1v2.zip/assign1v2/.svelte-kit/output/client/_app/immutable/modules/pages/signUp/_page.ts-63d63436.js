import{l}from"../../../chunks/_page-1079ec33.js";export{l as load};
