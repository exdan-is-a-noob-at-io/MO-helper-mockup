import{l}from"../../../chunks/_page-df57698a.js";export{l as load};
