import{l}from"../../../chunks/_page-816eaffb.js";export{l as load};
