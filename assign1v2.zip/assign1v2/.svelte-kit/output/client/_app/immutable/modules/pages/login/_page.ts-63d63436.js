import{l}from"../../../chunks/_page-e76ae232.js";export{l as load};
