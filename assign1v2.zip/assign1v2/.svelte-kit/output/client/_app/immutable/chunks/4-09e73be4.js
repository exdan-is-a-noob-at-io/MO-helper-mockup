import{_ as r}from"./_page-816eaffb.js";import{default as t}from"../components/pages/empty/_page.svelte-6b628d40.js";export{t as component,r as universal};
