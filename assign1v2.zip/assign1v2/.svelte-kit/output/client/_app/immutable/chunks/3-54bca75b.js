import{_ as r}from"./_page-df57698a.js";import{default as t}from"../components/pages/contact/_page.svelte-6325eaac.js";export{t as component,r as universal};
