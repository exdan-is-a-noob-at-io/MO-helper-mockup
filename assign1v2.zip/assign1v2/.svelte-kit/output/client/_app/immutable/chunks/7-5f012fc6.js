import{_ as r}from"./_page-816df066.js";import{default as t}from"../components/pages/search/_page.svelte-05087573.js";export{t as component,r as universal};
