const e=""+new URL("../assets/eye-779e0209.svg",import.meta.url).href,s=""+new URL("../assets/eyeClosed-fab6e59f.svg",import.meta.url).href;export{e as a,s as e};
