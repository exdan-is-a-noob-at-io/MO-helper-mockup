import{_ as r}from"./_page-e58add58.js";import{default as t}from"../components/pages/question/_question_id_/_page.svelte-9ae4c06b.js";export{t as component,r as universal};
