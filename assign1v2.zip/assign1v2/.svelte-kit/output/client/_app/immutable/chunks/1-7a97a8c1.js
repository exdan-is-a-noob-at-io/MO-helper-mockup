import{default as t}from"../components/error.svelte-ef8ac4ec.js";export{t as component};
