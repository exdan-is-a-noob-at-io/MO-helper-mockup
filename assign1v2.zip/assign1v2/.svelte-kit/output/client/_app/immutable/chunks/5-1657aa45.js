import{_ as r}from"./_page-e76ae232.js";import{default as t}from"../components/pages/login/_page.svelte-7368dcd5.js";export{t as component,r as universal};
