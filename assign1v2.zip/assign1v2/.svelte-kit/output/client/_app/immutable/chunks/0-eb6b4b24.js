import{default as t}from"../components/pages/_layout.svelte-8b082790.js";export{t as component};
