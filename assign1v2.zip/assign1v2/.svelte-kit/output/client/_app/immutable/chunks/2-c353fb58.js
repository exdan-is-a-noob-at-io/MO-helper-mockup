import{default as t}from"../components/pages/_page.svelte-d8237e60.js";export{t as component};
