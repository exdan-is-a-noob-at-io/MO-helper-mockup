import{_ as r}from"./_page-1079ec33.js";import{default as t}from"../components/pages/signUp/_page.svelte-f4299435.js";export{t as component,r as universal};
