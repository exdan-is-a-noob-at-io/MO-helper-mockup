<script lang="ts">
    console.log("hi")
</script>