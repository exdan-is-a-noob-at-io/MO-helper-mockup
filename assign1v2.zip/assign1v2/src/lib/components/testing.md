## Other typical markdown text

$$e=mc^2$$